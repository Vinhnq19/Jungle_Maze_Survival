# Room network benchmark

Local UDP v2/WebSocket network-only stability; no gameplay capacity claim.

Run: `room-bench-20261016-072749-137394`. Commit: `1bfc796cffe02e603b3cd52456f449431641d637`; actual source SHA256: `e42d83cd2e0d1d7440b10ce0a1ac4d0a44a3d2e3f80db474b8327f32ba26c939`.

GameServer: 256MiB, 30Hz fixed tick with NO gameplay. Client: 30 ping/s/session.
Local Docker Desktop results do not establish EC2 or Unity gameplay capacity.

| Sessions | Seconds | Verdict | Send Hz/client | RTT p95/p99 ms | Tick Hz | CPU peak % of core | RAM peak % |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 10 | 300 | PASS | 30.00 | 46.9213/60.3474 | 30.00 | 11.00 | 13.66 |
| 10 | 300 | PASS | 29.99 | 16.1716/31.3081 | 30.00 | 16.91 | 19.07 |


CPU criterion uses the highest server metric window; memory uses sampled cgroup v2 memory.current or v1 memory.usage_in_bytes (includes container overhead/cache).
RTT uses nearest-rank percentiles over measured pongs; warm-up excluded and final pongs drained for up to 5.2s.
Generator below 28.5Hz/client marks the run INVALID; missing telemetry fails it.

Environment and per-client raw samples are in JSON; stage summary is in CSV.
Cleanup errors: none
